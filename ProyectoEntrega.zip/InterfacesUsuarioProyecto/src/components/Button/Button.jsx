import React from 'react';
import './Button.css';


export function Button({ label, logo, variant, onClick, labelStyle }) {
  return (
    <button
      className={`button ${variant}`}
      onClick={onClick}
      aria-label={label || 'Button'} 
    >
      {logo && <div className={logo} aria-hidden="true" />}
      <span className={labelStyle}>
        {label || <span className="visually-hidden">Button</span>}
      </span>
    </button>
  );
}

