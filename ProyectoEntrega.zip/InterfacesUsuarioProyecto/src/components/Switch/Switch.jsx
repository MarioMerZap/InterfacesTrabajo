import { useState } from 'react';
import './Switch.css';
import '../../global.css';

export function Switch({ initialValue = false, onToggle, ariaLabel = 'Toggle setting', id }) {
  const [isOn, setIsOn] = useState(initialValue);

  function handleToggle() {
    const newValue = !isOn;
    setIsOn(newValue);

    if (onToggle) {
      onToggle(newValue);
    }
  }

  return (
    <button
      id={id}
      className={`toggle-switch ${isOn ? 'on' : 'off'}`}
      onClick={handleToggle}
      aria-pressed={isOn}
      aria-label={ariaLabel} // ✅ Etiqueta accesible
      role="switch" // ✅ Semántica de switch
      aria-checked={isOn} // ✅ Valor accesible
    >
      <span className="toggle-handle" />
    </button>
  );
}
